"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ruConfig = void 0;
/**
 * Russian language configuration for Natural Language Processing
 * Translated patterns for Russian-speaking users
 */
exports.ruConfig = {
    code: "ru",
    name: "Русский",
    chronoLocale: "ru", // chrono-node has Russian support
    dateTriggers: {
        due: ["срок", "дедлайн", "до", "к", "сдать до"],
        scheduled: ["запланировано на", "начать", "работать над", "на"],
    },
    recurrence: {
        frequencies: {
            daily: ["ежедневно", "каждый день", "ежедневный", "каждодневный"],
            weekly: ["еженедельно", "каждую неделю", "еженедельный"],
            monthly: ["ежемесячно", "каждый месяц", "ежемесячный"],
            yearly: ["ежегодно", "каждый год", "ежегодный"],
        },
        every: ["каждый", "каждую", "каждое", "все"],
        other: ["другой", "другую", "другое"],
        weekdays: {
            monday: ["понедельник"],
            tuesday: ["вторник"],
            wednesday: ["среда"],
            thursday: ["четверг"],
            friday: ["пятница"],
            saturday: ["суббота"],
            sunday: ["воскресенье"],
        },
        pluralWeekdays: {
            monday: ["по понедельникам"],
            tuesday: ["по вторникам"],
            wednesday: ["по средам"],
            thursday: ["по четвергам"],
            friday: ["по пятницам"],
            saturday: ["по субботам"],
            sunday: ["по воскресеньям"],
        },
        ordinals: {
            first: ["первый", "первая", "первое"],
            second: ["второй", "вторая", "второе"],
            third: ["третий", "третья", "третье"],
            fourth: ["четвертый", "четвертая", "четвертое"],
            last: ["последний", "последняя", "последнее"],
        },
        periods: {
            day: ["день", "дни"],
            week: ["неделя", "недели"],
            month: ["месяц", "месяцы"],
            year: ["год", "годы"],
        },
    },
    timeEstimate: {
        hours: ["ч", "час", "часа", "часов"],
        minutes: ["м", "мин", "минута", "минуты", "минут"],
    },
    fallbackStatus: {
        open: ["открыто", "к выполнению", "новое", "todo"],
        inProgress: ["в работе", "выполняется", "в процессе"],
        done: ["выполнено", "готово", "завершено", "сделано"],
        cancelled: ["отменено", "отменён", "отменена"],
        waiting: ["ожидание", "заблокировано", "на паузе"],
    },
    fallbackPriority: {
        urgent: ["срочно", "критично", "экстренно", "немедленно"],
        high: ["высокий", "высокая", "важно", "приоритетно"],
        normal: ["нормальный", "нормальная", "средний", "средняя"],
        low: ["низкий", "низкая", "неважно", "можно позже"],
    },
};
//# sourceMappingURL=ru.js.map