"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MappedText = void 0;
/**
 * Text derived from an input string that remembers where each character came from,
 * so positions found after rewriting (placeholders, normalized dates) can be
 * reported against the original input.
 */
class MappedText {
    constructor() {
        this.text = "";
        this.starts = [];
        this.ends = [];
    }
    static from(source) {
        const mapped = new MappedText();
        mapped.text = source;
        for (let index = 0; index < source.length; index += 1) {
            mapped.starts.push(index);
            mapped.ends.push(index + 1);
        }
        return mapped;
    }
    /** Appends replacement text standing for source[sourceStart, sourceEnd). */
    append(text, sourceStart, sourceEnd) {
        this.text += text;
        for (let index = 0; index < text.length; index += 1) {
            this.starts.push(sourceStart);
            this.ends.push(sourceEnd);
        }
    }
    /** Appends this[start, end) of another mapped text, keeping its mapping. */
    appendFrom(other, start, end) {
        this.text += other.text.slice(start, end);
        this.starts.push(...other.starts.slice(start, end));
        this.ends.push(...other.ends.slice(start, end));
    }
    /** Appends text standing for other[start, end): a replacement of that range. */
    appendReplacing(other, start, end, text) {
        const [sourceStart, sourceEnd] = other.sourceRange(start, end);
        this.append(text, sourceStart, sourceEnd);
    }
    slice(start, end = this.text.length) {
        const sliced = new MappedText();
        sliced.appendFrom(this, start, end);
        return sliced;
    }
    /** Source range for text[start, end). */
    sourceRange(start, end) {
        if (this.text.length === 0)
            return [0, 0];
        const first = Math.min(Math.max(start, 0), this.text.length - 1);
        const last = Math.min(Math.max(end - 1, first), this.text.length - 1);
        return [this.starts[first], this.ends[last]];
    }
    /**
     * Replaces matches of a global pattern. The callback returns the replacement,
     * or null to keep the match unchanged.
     */
    replace(pattern, replacer) {
        const result = new MappedText();
        let last = 0;
        for (const match of this.text.matchAll(pattern)) {
            const replacement = replacer(match);
            if (replacement === null)
                continue;
            const start = match.index;
            const end = start + match[0].length;
            result.appendFrom(this, last, start);
            result.appendReplacing(this, start, end, replacement);
            last = end;
        }
        result.appendFrom(this, last, this.text.length);
        return result;
    }
}
exports.MappedText = MappedText;
//# sourceMappingURL=MappedText.js.map