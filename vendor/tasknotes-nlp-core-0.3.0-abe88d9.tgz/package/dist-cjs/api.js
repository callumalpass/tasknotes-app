"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTaskParser = createTaskParser;
exports.toEngineConfig = toEngineConfig;
const TaskParserEngine_js_1 = require("./TaskParserEngine.js");
const index_js_1 = require("./languages/index.js");
/**
 * Creates a parser for task input such as
 * `Pay rent tomorrow 9am #finance every month`.
 */
function createTaskParser(options = {}) {
    const engine = new TaskParserEngine_js_1.TaskParserEngine(toEngineConfig(options));
    const fields = options.fields ?? [];
    const statuses = options.statuses ?? [];
    return {
        language: engine.languageCode,
        parse(input, parseOptions = {}) {
            const { data, spans } = engine.parse(input, parseOptions.referenceDate);
            return { task: toTask(data, fields, statuses, (text) => engine.parseDateValue(text, parseOptions.referenceDate)), spans };
        },
    };
}
function toEngineConfig(options) {
    const [languageCode, region] = (options.language ?? "en").split(/[-_]/);
    const language = (0, index_js_1.mergeLanguageConfig)((0, index_js_1.getLanguageConfig)(languageCode.toLowerCase()), options.languageOverrides);
    const triggers = options.triggers ?? {};
    const trigger = (value, fallback) => value === undefined ? fallback : value;
    const entries = [
        ["tags", trigger(triggers.tag, "#")],
        ["contexts", trigger(triggers.context, "@")],
        ["projects", trigger(triggers.project, "+")],
        ["status", trigger(triggers.status, "*")],
        ["priority", trigger(triggers.priority, false)],
        ...(options.fields ?? []).map((field) => [field.id, field.trigger]),
    ];
    const nlpTriggers = {
        triggers: entries.map(([propertyId, value]) => ({
            propertyId,
            trigger: value || "",
            enabled: Boolean(value),
        })),
    };
    const userFields = (options.fields ?? []).map((field) => ({
        id: field.id,
        displayName: field.id,
        key: field.id,
        type: field.type,
    }));
    return {
        language,
        statuses: (options.statuses ?? []).map((status) => ({
            value: status.value,
            label: status.label ?? status.value,
            aliases: status.aliases ?? [],
        })),
        priorities: (options.priorities ?? []).map((priority) => ({
            value: priority.value,
            label: priority.label ?? priority.value,
            aliases: priority.aliases ?? [],
        })),
        defaultToScheduled: (options.defaultDateField ?? "scheduled") === "scheduled",
        triggers: nlpTriggers,
        userFields,
        dateLocale: options.locale ?? (region ? options.language : undefined),
        dateOrder: options.dateOrder,
        referenceDate: options.referenceDate,
        features: {
            dates: options.features?.dates ?? true,
            recurrence: options.features?.recurrence ?? true,
            estimate: options.features?.estimate ?? true,
            priority: options.features?.priority ?? true,
            status: options.features?.status ?? true,
        },
    };
}
const BUILT_IN_COMPLETED_STATUSES = new Set(["done", "cancelled"]);
function toTask(data, fields, statuses, parseDate) {
    const task = {
        title: data.title,
        tags: data.tags,
        contexts: data.contexts,
        projects: data.projects,
        fields: {},
    };
    if (data.details)
        task.details = data.details;
    if (data.scheduledDate) {
        task.scheduled = { date: data.scheduledDate, ...(data.scheduledTime && { time: data.scheduledTime }) };
    }
    if (data.dueDate)
        task.due = { date: data.dueDate, ...(data.dueTime && { time: data.dueTime }) };
    if (data.status) {
        task.status = data.status;
        const configured = statuses.find((status) => status.value === data.status);
        task.completed = configured
            ? Boolean(configured.completed)
            : statuses.length === 0 && BUILT_IN_COMPLETED_STATUSES.has(data.status);
    }
    if (data.priority)
        task.priority = data.priority;
    if (data.recurrence)
        task.recurrence = data.recurrence;
    if (data.estimate)
        task.estimate = data.estimate;
    for (const [id, value] of Object.entries(data.userFields ?? {})) {
        const type = fields.find((field) => field.id === id)?.type;
        task.fields[id] = normalizeFieldValue(value, type, parseDate);
    }
    return task;
}
function normalizeFieldValue(value, type, parseDate) {
    if (Array.isArray(value))
        return value;
    switch (type) {
        case "boolean": {
            const normalized = value.trim().toLowerCase();
            return normalized === "true" ? true : normalized === "false" ? false : value;
        }
        case "number": {
            const number = Number(value.replace(",", "."));
            return value.trim() !== "" && Number.isFinite(number) ? number : value;
        }
        case "date":
            return parseDate(value) ?? value;
        case "list":
            return [value];
        default:
            return value;
    }
}
//# sourceMappingURL=api.js.map