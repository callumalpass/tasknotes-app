"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.NaturalLanguageParserCore = void 0;
const rruleModule = __importStar(require("rrule"));
const index_js_1 = require("./languages/index.js");
const defaults_js_1 = require("./defaults.js");
const TaskParserEngine_js_1 = require("./TaskParserEngine.js");
const RRule = rruleModule.RRule;
/**
 * The TaskNotes plugin's parser interface. New code should use createTaskParser,
 * which also returns spans and typed field values.
 */
class NaturalLanguageParserCore {
    constructor(statusConfigs = [], priorityConfigs = [], defaultToScheduled = true, languageCode = "en", nlpTriggers, userFields, options = {}) {
        this.statusConfigs = statusConfigs;
        this.engine = new TaskParserEngine_js_1.TaskParserEngine({
            language: (0, index_js_1.getLanguageConfig)(languageCode),
            statuses: statusConfigs.map(({ value, label }) => ({ value, label, aliases: [] })),
            priorities: priorityConfigs.map(({ value, label }) => ({ value, label, aliases: [] })),
            defaultToScheduled,
            triggers: nlpTriggers || defaults_js_1.DEFAULT_NLP_TRIGGERS,
            userFields: userFields || [],
            dateLocale: options.dateLocale,
            dateOrder: options.dateOrder,
            referenceDate: options.referenceDate,
            features: { dates: true, recurrence: true, estimate: true, priority: true, status: true },
        });
    }
    /** Parses task input. An input with nothing left for a title gets "Untitled Task". */
    parseInput(input) {
        return this.parseInputWithSpans(input).data;
    }
    /** Parses task input and also returns where each value was found, in input order. */
    parseInputWithSpans(input) {
        const { data, spans } = this.engine.parse(input);
        if (!data.title)
            data.title = "Untitled Task";
        return { data, spans };
    }
    /**
     * Generates a user-friendly preview of the parsed data.
     * Icons are placeholders for the UI layer to interpret.
     */
    getPreviewData(parsed) {
        const parts = [];
        if (parsed.title)
            parts.push({ icon: "edit-3", text: `"${parsed.title}"` });
        if (parsed.details)
            parts.push({
                icon: "file-text",
                text: `Details: "${parsed.details.substring(0, 50)}${parsed.details.length > 50 ? "..." : ""}"`,
            });
        if (parsed.dueDate) {
            const dateStr = parsed.dueTime
                ? `${parsed.dueDate} at ${parsed.dueTime}`
                : parsed.dueDate;
            parts.push({ icon: "calendar", text: `Due: ${dateStr}` });
        }
        if (parsed.scheduledDate) {
            const dateStr = parsed.scheduledTime
                ? `${parsed.scheduledDate} at ${parsed.scheduledTime}`
                : parsed.scheduledDate;
            parts.push({ icon: "calendar-clock", text: `Scheduled: ${dateStr}` });
        }
        if (parsed.priority)
            parts.push({ icon: "alert-triangle", text: `Priority: ${parsed.priority}` });
        if (parsed.status)
            parts.push({ icon: "activity", text: `Status: ${parsed.status}` });
        if (parsed.contexts && parsed.contexts.length > 0)
            parts.push({
                icon: "map-pin",
                text: `Contexts: ${parsed.contexts.map((c) => "@" + c).join(", ")}`,
            });
        if (parsed.projects && parsed.projects.length > 0) {
            // Display projects with + prefix (no need to wrap in brackets - just show what was parsed)
            const projectDisplay = parsed.projects.map((p) => `+${p}`).join(", ");
            parts.push({ icon: "folder", text: `Projects: ${projectDisplay}` });
        }
        if (parsed.tags && parsed.tags.length > 0)
            parts.push({
                icon: "tag",
                text: `Tags: ${parsed.tags.map((t) => "#" + t).join(", ")}`,
            });
        if (parsed.recurrence) {
            let recurrenceText = "Invalid recurrence";
            try {
                if (this.engine.isValidRecurrence(parsed.recurrence)) {
                    recurrenceText = RRule.fromString(parsed.recurrence).toText();
                }
            }
            catch (error) {
                console.debug("Error parsing rrule for preview:", error);
            }
            parts.push({ icon: "repeat", text: `Recurrence: ${recurrenceText}` });
        }
        if (parsed.estimate)
            parts.push({ icon: "clock", text: `Estimate: ${parsed.estimate} min` });
        // User-defined fields
        if (parsed.userFields && Object.keys(parsed.userFields).length > 0) {
            for (const [fieldId, value] of Object.entries(parsed.userFields)) {
                const displayName = this.engine.getUserField(fieldId)?.displayName || fieldId;
                const displayValue = Array.isArray(value) ? value.join(", ") : value;
                parts.push({ icon: "box", text: `${displayName}: ${displayValue}` });
            }
        }
        return parts;
    }
    /**
     * Generates a simple text-only preview of the parsed data.
     */
    getPreviewText(parsed) {
        return this.getPreviewData(parsed)
            .map((part) => part.text)
            .join(" • ");
    }
    /**
     * Get status suggestions for autocomplete
     */
    getStatusSuggestions(query, limit = 10) {
        const q = query.toLowerCase();
        return this.statusConfigs
            .filter((s) => s && typeof s.value === "string" && typeof s.label === "string")
            .filter((s) => s.value.trim() !== "" && s.label.trim() !== "")
            .filter((s) => s.value.toLowerCase().includes(q) || s.label.toLowerCase().includes(q))
            .slice(0, limit)
            .map((s) => ({
            value: s.value,
            label: s.label,
            display: s.label,
        }));
    }
}
exports.NaturalLanguageParserCore = NaturalLanguageParserCore;
//# sourceMappingURL=NaturalLanguageParserCore.js.map