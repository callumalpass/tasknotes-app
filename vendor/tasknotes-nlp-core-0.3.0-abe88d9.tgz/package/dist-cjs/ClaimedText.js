"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClaimedText = void 0;
const MARKERS = {
    date: "",
    estimate: "",
    recurrence: "",
    keyword: "",
};
const ANY_MARKER = "[-]";
const MARKER_RUN = `${ANY_MARKER}(?:\\s*${ANY_MARKER})*`;
const SEPARATOR = "[,;:–—，；：、-]";
/**
 * Tracks which parts of a task line each parsing stage has used, so stages work on
 * stable original offsets and the title is built once from what remains.
 */
class ClaimedText {
    constructor(text) {
        this.text = text;
        this.kinds = new Array(text.length);
    }
    /**
     * Returns the text later stages should read: unclaimed, trimmed, with each blank
     * left by a claim collapsed to one space. Other whitespace is kept as written.
     */
    view() {
        let text = "";
        const map = [];
        for (let index = 0; index < this.text.length;) {
            if (!this.isBlank(index)) {
                text += this.text[index];
                map.push(index);
                index += 1;
                continue;
            }
            const start = index;
            let touchesClaim = false;
            while (index < this.text.length && this.isBlank(index)) {
                touchesClaim || (touchesClaim = this.kinds[index] !== undefined);
                index += 1;
            }
            if (text.length === 0 || index === this.text.length)
                continue;
            if (touchesClaim) {
                text += " ";
                map.push(start);
            }
            else {
                text += this.text.slice(start, index);
                for (let offset = start; offset < index; offset += 1)
                    map.push(offset);
            }
        }
        return { text, map };
    }
    isBlank(index) {
        return this.kinds[index] !== undefined || /\s/u.test(this.text[index]);
    }
    /**
     * Claims view[start, end) for a stage and returns the range in the original text.
     * Already-claimed characters keep their kind.
     */
    claim(view, start, end, kind) {
        var _a;
        if (end <= start || start < 0 || end > view.map.length)
            return null;
        const originalStart = view.map[start];
        const originalEnd = view.map[end - 1] + 1;
        for (let index = originalStart; index < originalEnd; index += 1) {
            (_a = this.kinds)[index] ?? (_a[index] = kind);
        }
        return [originalStart, originalEnd];
    }
    hasClaims() {
        return this.kinds.some((kind) => kind !== undefined && kind !== "shield");
    }
    /**
     * Builds the title from unclaimed text, removing the connectors and separators that
     * only made sense next to a removed value ("call Jo at 3pm" -> "call Jo").
     */
    buildTitle(connectors, { spaceless = false } = {}) {
        // Without spaces between words, a removed value leaves nothing behind.
        const gap = spaceless ? "" : " ";
        let title = "";
        for (let index = 0; index < this.text.length; index += 1) {
            const kind = this.kinds[index];
            if (kind === undefined || kind === "shield") {
                title += this.text[index];
            }
            else if (kind === "metadata") {
                title += " ";
            }
            else if (index === 0 || this.kinds[index - 1] !== kind) {
                // One marker per run; a space keeps neighbouring words apart.
                title += `${gap}${MARKERS[kind]}${gap}`;
            }
        }
        title = this.removeConnectors(title, connectors, spaceless);
        return this.removeMarkers(title, gap);
    }
    removeConnectors(title, connectors, spaceless) {
        for (const [kind, phrases] of Object.entries(connectors)) {
            const alternatives = phrases
                .filter((phrase) => phrase.trim().length > 0)
                .sort((a, b) => b.length - a.length)
                .map((phrase) => phrase.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+"))
                .join("|");
            if (!alternatives)
                continue;
            // Repeat so chained connectors go too: "should take about 2h".
            const pattern = new RegExp(`(${spaceless ? "" : "^|[\\s(]"})(?:${alternatives})\\s*(?=${MARKERS[kind]})`, "iu");
            let previous;
            do {
                previous = title;
                title = title.replace(pattern, "$1");
            } while (title !== previous);
        }
        return title;
    }
    removeMarkers(title, gap) {
        const rules = [
            [new RegExp(MARKER_RUN, "gu"), ""],
            // "urgent: fix it" -> "fix it"
            [new RegExp(`^\\s*${ANY_MARKER}\\s*${SEPARATOR}+\\s*`, "u"), ""],
            // "write post, about 2h" -> "write post"; "task every monday," -> "task"
            [new RegExp(`\\s*${SEPARATOR}*\\s*${ANY_MARKER}\\s*${SEPARATOR}*\\s*$`, "u"), ""],
            // "call (tomorrow)" -> "call"
            [new RegExp(`\\s*\\(\\s*${ANY_MARKER}\\s*\\)`, "gu"), ""],
            // "a, tomorrow, b" -> "a, b"
            [new RegExp(`(${SEPARATOR})\\s*${ANY_MARKER}\\s*${SEPARATOR}`, "gu"), "$1"],
            // "email Jo in 3 days, takes" leaves "Jo <m>, <m>": drop markers before punctuation.
            [new RegExp(`\\s*${ANY_MARKER}\\s*(?=[,;:.!?)\\]，。！？；：、）])`, "gu"), ""],
        ];
        let previous;
        do {
            previous = title;
            for (const [pattern, replacement] of rules) {
                title = title.replace(pattern, replacement);
            }
        } while (title !== previous);
        return title.replace(new RegExp(ANY_MARKER, "gu"), gap).replace(/\s+/g, " ").trim();
    }
}
exports.ClaimedText = ClaimedText;
//# sourceMappingURL=ClaimedText.js.map