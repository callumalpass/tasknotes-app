"use strict";
/**
 * English additions to chrono's casual parser for phrases common in task titles.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.extendEnglishParser = extendEnglishParser;
const NOT_WORD_BEFORE = "(?<![\\p{L}\\p{N}\\p{M}_])";
const NOT_WORD_AFTER = "(?![\\p{L}\\p{N}\\p{M}_])";
const HOUR_WORDS = {
    one: 1,
    two: 2,
    three: 3,
    four: 4,
    five: 5,
    six: 6,
    seven: 7,
    eight: 8,
    nine: 9,
    ten: 10,
    eleven: 11,
    twelve: 12,
};
const HOUR = `(\\d{1,2}|${Object.keys(HOUR_WORDS).join("|")})`;
const MERIDIEM = "(?:\\s*([ap])\\.?m\\.?)?";
// Fixed dates resolve to their next occurrence.
const HOLIDAYS = [
    { pattern: "christmas\\s+eve", month: 12, day: 24 },
    { pattern: "(?:christmas(?:\\s+day)?|xmas)", month: 12, day: 25 },
    { pattern: "new\\s+year['’]?s\\s+eve", month: 12, day: 31 },
    { pattern: "new\\s+year['’]?s(?:\\s+day)?", month: 1, day: 1 },
    { pattern: "halloween", month: 10, day: 31 },
];
// Abbreviations that are also words: "Sun" in "meeting with Sun Ltd", "the sun".
const WORD_LIKE_WEEKDAYS = new Set(["sun", "sat", "wed"]);
const NON_DATE_PRECEDING_WORDS = new Set(["the", "a", "an", "with", "of", "in", "from"]);
function toComponents(date) {
    return { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() };
}
function atNoon(reference) {
    const date = new Date(reference);
    date.setHours(12, 0, 0, 0);
    return date;
}
function parseHour(text) {
    return HOUR_WORDS[text.toLowerCase()] ?? Number(text);
}
/** Next date (today or later) with this day of month, skipping months without it. */
function nextDayOfMonth(reference, day) {
    const today = atNoon(reference);
    for (let offset = 0; offset < 12; offset += 1) {
        const candidate = new Date(today.getFullYear(), today.getMonth() + offset, day, 12);
        if (candidate.getDate() === day && candidate >= today)
            return candidate;
    }
    return null;
}
function nextAnnualDate(reference, month, day) {
    const today = atNoon(reference);
    const candidate = new Date(today.getFullYear(), month - 1, day, 12);
    if (candidate < today)
        candidate.setFullYear(candidate.getFullYear() + 1);
    return candidate;
}
/** End of a day, week (Friday), month or year, optionally the next one. */
function endOf(reference, period, next) {
    const date = atNoon(reference);
    switch (period) {
        case "week": {
            const daysToFriday = (5 - date.getDay() + 7) % 7;
            // On a weekend, this week's Friday has passed.
            date.setDate(date.getDate() + daysToFriday + (next && daysToFriday <= 4 ? 7 : 0));
            return date;
        }
        case "month":
            return new Date(date.getFullYear(), date.getMonth() + (next ? 2 : 1), 0, 12);
        case "year":
            return new Date(date.getFullYear() + (next ? 1 : 0), 11, 31, 12);
        default:
            if (next)
                date.setDate(date.getDate() + 1);
            return date;
    }
}
/**
 * Adds parsers and refiners to a cloned English chrono parser:
 * - "half past four", "quarter to 5", "4 o'clock"
 * - "the 15th" (next 15th of a month)
 * - "end of the month", "end of next week", "eod", "eow"
 * - "christmas", "new year's eve" and similar fixed dates
 * - bare hours from 1 to 6, such as "at 3", mean the afternoon
 * - word-like abbreviations ("Sun Ltd") are not weekdays
 */
function extendEnglishParser(parser) {
    parser.parsers.push({
        pattern: () => new RegExp(`${NOT_WORD_BEFORE}(?:at\\s+)?(half|quarter)\\s+(past|after|to)\\s+${HOUR}${MERIDIEM}${NOT_WORD_AFTER}`, "iu"),
        extract: (_context, match) => {
            let hour = parseHour(match[3]);
            const minutes = match[1].toLowerCase() === "half" ? 30 : 15;
            let minute = minutes;
            if (match[2].toLowerCase() === "to") {
                hour = hour === 1 ? 12 : hour - 1;
                minute = 60 - minutes;
            }
            if (hour < 1 || hour > 12)
                return null;
            return withMeridiem({ hour, minute }, match[4]);
        },
    }, {
        pattern: () => new RegExp(`${NOT_WORD_BEFORE}(?:at\\s+)?${HOUR}\\s*o['’]?clock${MERIDIEM}${NOT_WORD_AFTER}`, "iu"),
        extract: (_context, match) => {
            const hour = parseHour(match[1]);
            if (hour < 1 || hour > 12)
                return null;
            return withMeridiem({ hour, minute: 0 }, match[2]);
        },
    }, {
        // Only "the 15th" before the end of the phrase, a time or metadata:
        // "review the 2nd draft" stays a title.
        pattern: () => new RegExp(`${NOT_WORD_BEFORE}the\\s+(\\d{1,2})(?:st|nd|rd|th)(?:\\s+of\\s+(?:the|this)\\s+month)?(?=\\s*(?:$|[,;.)#@+]|(?:at|by|before|from|to|until|and)${NOT_WORD_AFTER}|\\d))`, "iu"),
        extract: (context, match) => {
            const date = nextDayOfMonth(context.refDate, Number(match[1]));
            return date ? toComponents(date) : null;
        },
    }, {
        pattern: () => new RegExp(`${NOT_WORD_BEFORE}(?:the\\s+)?end\\s+of\\s+(?:(the|this|next)\\s+)?(day|week|month|year)${NOT_WORD_AFTER}`, "iu"),
        extract: (context, match) => toComponents(endOf(context.refDate, match[2].toLowerCase(), match[1]?.toLowerCase() === "next")),
    }, {
        pattern: () => new RegExp(`${NOT_WORD_BEFORE}eo([dwmy])${NOT_WORD_AFTER}`, "iu"),
        extract: (context, match) => {
            const period = { d: "day", w: "week", m: "month", y: "year" }[match[1].toLowerCase()];
            return toComponents(endOf(context.refDate, period, false));
        },
    }, ...HOLIDAYS.map((holiday) => ({
        pattern: () => new RegExp(`${NOT_WORD_BEFORE}${holiday.pattern}${NOT_WORD_AFTER}`, "iu"),
        extract: (context) => toComponents(nextAnnualDate(context.refDate, holiday.month, holiday.day)),
    })));
    // Before chrono's own refiners, so forwardDate sees the corrected hour.
    parser.refiners.unshift({
        refine: (context, results) => results.filter((result) => !isWordLikeWeekday(context.text, result)),
    }, {
        refine: (_context, results) => {
            for (const result of results) {
                assumeAfternoon(result.text, result.start);
                if (result.end)
                    assumeAfternoon(result.text, result.end);
            }
            return results;
        },
    });
    return parser;
}
function withMeridiem(components, meridiem) {
    if (!meridiem)
        return components;
    const pm = meridiem.toLowerCase() === "p";
    const hour = (components.hour % 12) + (pm ? 12 : 0);
    return { ...components, hour, meridiem: pm ? 1 : 0 };
}
/** "at 3" means 15:00. Written 24-hour times ("03:30") and explicit am/pm keep their hour. */
function assumeAfternoon(text, components) {
    if (!components.isCertain("hour") || components.isCertain("meridiem"))
        return;
    const hour = components.get("hour");
    if (hour < 1 || hour > 6 || /(?<!\d)0\d/.test(text) || /\b(?:am|a\.m\.)/i.test(text))
        return;
    components.assign("hour", hour + 12);
    components.assign("meridiem", 1);
}
function isWordLikeWeekday(text, result) {
    const matched = result.text.trim().replace(/\.$/, "");
    if (!WORD_LIKE_WEEKDAYS.has(matched.toLowerCase()))
        return false;
    const before = text.slice(0, result.index).trim().split(/\s+/).pop()?.toLowerCase() ?? "";
    if (NON_DATE_PRECEDING_WORDS.has(before))
        return true;
    // A capitalised abbreviation followed by a capitalised word reads as a name.
    const after = text.slice(result.index + result.text.length).trim();
    return /^\p{Lu}/u.test(matched) && /^\p{Lu}/u.test(after);
}
//# sourceMappingURL=chronoExtensions.js.map