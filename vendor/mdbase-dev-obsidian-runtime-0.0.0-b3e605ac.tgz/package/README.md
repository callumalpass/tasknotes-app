# @mdbase-dev/obsidian-runtime

The mdbase-next runtime host inside Obsidian (desktop and mobile). Plugins
(TaskNotes, mdbase-obsidian) embed it and share one instance per app process.

Owner: the **obsidian** workstream (`docs/SHIP.md`).

## What it provides

| Module | What | Status |
|---|---|---|
| `src/embed/` | Embedded-WASM loading: table-driven base64 decoder + gzip (S5 §5) | done |
| `src/shared/` | The shared runtime: `globalThis.__mdbase_runtime__` keyed by ABI major, one instance per runtime version, the version-skew rule, handoff (`replica-client-api.md` §13) | done |
| `src/journal/` | The dual `Journal`: IndexedDB `strict` + CRC-framed append-only vault file, union recovery, A/B compaction (S4 §4) | done |
| `src/vault/` | The vault `FilePlatform` (`GuardedInPlace`) over Obsidian's vault/adapter API: guarded replace/create/trash, events, move pairing, Android case-only renames, sync-tool detection (S3 §5) | done |
| `src/index/` | `IndexStorage` on sqlite-wasm `opfs-sahpool` in the runtime's Worker (S4 §7) | done |
| `src/fence/` | The editor fence: `fence_report` / `fence_apply` through CodeMirror (S3 §4, contract §14) | done |

The Rust side of each interface is in `crates/store-file` (see
`docs/ship/interfaces/2026-10-04-file-fileplatform-indexstorage.md`).

| `src/keys/` | Private sync: device key storage, commit-then-reveal approval, recovery key, status UI | done |
| `e2e/` | Isolated desktop Obsidian (`desktop.sh`, `run-desktop.mjs`) and Android emulator (`android.sh`, `run-android.mjs`) suites | done |

## E2E results (desktop Linux, Obsidian 1.13.7, `e2e/results/`)

- **Editor fence**, typing every 80 ms while publishing every 250 ms for 20 s:
  - 79/79 publishes applied, 0 lost keystrokes, 0 on-disk regressions, p50 2.4 ms;
  - naive `vault.process`: 1 regression (an earlier run had 2 regressions and 14 lost keystrokes).
- **Dual journal:** ack p50 3.4 ms (IndexedDB strict 2.8 ms, vault append 0.6 ms).
  - Across 5 kill -9 trials (about 28k acks), 0 acknowledged entries were lost and both copies read back intact.
- **sahpool index:** WAL + EXCLUSIVE, open 81–232 ms, 10k build 0.3 s, queries about 2 ms.
  - A second opener gets `Busy`.
  - After a kill it reports `Unclean`; after a clean restart, `Existing`.
- **Vault platform:**
  - guarded replace, create and trash;
  - the BOM is preserved;
  - rename onto an occupied path → `AlreadyExists`;
  - case-only renames go through a temporary name;
  - an outside `mv` is paired as `RenamedFrom`/`RenamedTo`.
- **Keys:** stored in SecretStorage (keychain) and reloaded after restart.

## E2E results (Android 16 emulator, Obsidian 1.13.8, WebView 133; `e2e/results/android-emulator.json`)

- **Editor fence under typing:** 73/73 applied, 0 lost keystrokes, 0 disk regressions, p50 6.6 ms.
  - Naive `vault.process`: **12 disk regressions, and the final value was wrong** (33 instead of 50).
- **Dual journal:** ack p50 5.6 ms. Across 5 `am force-stop` trials (about 23k acks), 0 acknowledged entries were lost.
- **sahpool index:** WAL + EXCLUSIVE, open 240–480 ms, a second opener gets `Busy`.
- **Vault platform:**
  - a case-variant create on shared storage is refused (`Exists`);
  - a case-only rename via a temporary name keeps the file (the bridge rename alone deletes it, S3);
  - an outside `mv` is paired.

**Untested: iOS.** Whether `adapter.append` to a dot-folder (`.mdbase/devices/…`) works and is durable on iOS is still open. There is no macOS or iOS device here. On iOS, check `journal-a.log` after the `journal` suite, and the `kills` suite.

## Sharing rules

- Every plugin embeds a byte-identical runtime build and calls
  `sharedRuntime(ABI_MAJOR).register(pluginId, info, create)`. The first plugin
  with a version instantiates it; others reuse it.
- `attach(plugin, version, collectionId, ctx)` decides host / client / handoff /
  daemon / `upgrade_required`. Attachments re-home after a handoff
  (`onRehome`).
- The registry object on the global is created by whichever plugin loads first,
  so its method set is part of the ABI: change it only with an ABI major bump.

## Checks

```sh
npm ci && npm run typecheck && npm test && npm run build   # or: cargo xtask obsidian
```
