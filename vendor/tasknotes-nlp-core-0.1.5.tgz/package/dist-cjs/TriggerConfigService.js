"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TriggerConfigService = void 0;
/**
 * Service for managing and querying NLP trigger configurations
 */
class TriggerConfigService {
    constructor(config, userFields = []) {
        this.config = config;
        this.userFields = userFields;
        this.triggerMap = new Map();
        this.propertyMap = new Map();
        this.buildMaps();
    }
    /**
     * Build lookup maps for efficient queries
     */
    buildMaps() {
        this.triggerMap.clear();
        this.propertyMap.clear();
        for (const triggerConfig of this.config.triggers) {
            if (triggerConfig.enabled) {
                this.triggerMap.set(triggerConfig.trigger, triggerConfig);
                this.propertyMap.set(triggerConfig.propertyId, triggerConfig);
            }
        }
    }
    /**
     * Get trigger config for a specific property
     */
    getTriggerForProperty(propertyId) {
        return this.propertyMap.get(propertyId);
    }
    /**
     * Get property ID for a trigger string
     */
    getPropertyForTrigger(trigger) {
        return this.triggerMap.get(trigger)?.propertyId;
    }
    /**
     * Get all enabled triggers
     */
    getAllEnabledTriggers() {
        return this.config.triggers.filter((t) => t.enabled);
    }
    /**
     * Get all enabled triggers sorted by trigger length (longest first)
     * This ensures multi-character triggers are matched before single-character ones
     */
    getTriggersOrderedByLength() {
        return this.getAllEnabledTriggers().sort((a, b) => b.trigger.length - a.trigger.length);
    }
    /**
     * Check if a trigger is using Obsidian's native tag suggester
     */
    usesNativeTagSuggester() {
        const tagTrigger = this.getTriggerForProperty("tags");
        return tagTrigger?.trigger === "#" && tagTrigger?.enabled;
    }
    /**
     * Get the trigger string for tags (or undefined if disabled)
     */
    getTagTrigger() {
        const config = this.getTriggerForProperty("tags");
        return config?.enabled ? config.trigger : undefined;
    }
    /**
     * Get the trigger string for contexts (or undefined if disabled)
     */
    getContextTrigger() {
        const config = this.getTriggerForProperty("contexts");
        return config?.enabled ? config.trigger : undefined;
    }
    /**
     * Get the trigger string for projects (or undefined if disabled)
     */
    getProjectTrigger() {
        const config = this.getTriggerForProperty("projects");
        return config?.enabled ? config.trigger : undefined;
    }
    /**
     * Get the trigger string for status (or undefined if disabled)
     */
    getStatusTrigger() {
        const config = this.getTriggerForProperty("status");
        return config?.enabled ? config.trigger : undefined;
    }
    /**
     * Get the trigger string for priority (or undefined if disabled)
     */
    getPriorityTrigger() {
        const config = this.getTriggerForProperty("priority");
        return config?.enabled ? config.trigger : undefined;
    }
    /**
     * Get user field definition by ID
     */
    getUserField(fieldId) {
        return this.userFields.find((f) => f.id === fieldId);
    }
    /**
     * Check if a property ID is a user-defined field
     */
    isUserField(propertyId) {
        return this.userFields.some((f) => f.id === propertyId);
    }
    /**
     * Determine suggester type for a property
     */
    getSuggesterType(propertyId) {
        // Built-in property types
        if (propertyId === "tags") {
            return this.usesNativeTagSuggester() ? "native-tag" : "list";
        }
        if (propertyId === "contexts")
            return "list";
        if (propertyId === "projects")
            return "file";
        if (propertyId === "status")
            return "status";
        if (propertyId === "priority")
            return "priority";
        // User-defined fields
        const userField = this.getUserField(propertyId);
        if (userField) {
            switch (userField.type) {
                case "text":
                    // If it has autosuggest config, use file suggester
                    return userField.autosuggestFilter ? "file" : "list";
                case "list":
                    return "list";
                case "boolean":
                    return "boolean";
                default:
                    return "none";
            }
        }
        return "none";
    }
    /**
     * Update the configuration (rebuilds internal maps)
     */
    updateConfig(config) {
        this.config = config;
        this.buildMaps();
    }
    /**
     * Update user fields (rebuilds internal maps if needed)
     */
    updateUserFields(userFields) {
        this.userFields = userFields;
        // User fields don't affect trigger map, but we might want to rebuild in the future
    }
}
exports.TriggerConfigService = TriggerConfigService;
//# sourceMappingURL=TriggerConfigService.js.map