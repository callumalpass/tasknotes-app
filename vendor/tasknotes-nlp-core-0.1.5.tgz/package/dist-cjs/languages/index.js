"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.languageRegistry = void 0;
exports.getAvailableLanguages = getAvailableLanguages;
exports.getLanguageConfig = getLanguageConfig;
exports.detectSystemLanguage = detectSystemLanguage;
const en_js_1 = require("./en.js");
const es_js_1 = require("./es.js");
const fr_js_1 = require("./fr.js");
const de_js_1 = require("./de.js");
const ru_js_1 = require("./ru.js");
const zh_js_1 = require("./zh.js");
const ja_js_1 = require("./ja.js");
const it_js_1 = require("./it.js");
const nl_js_1 = require("./nl.js");
const pt_js_1 = require("./pt.js");
const sv_js_1 = require("./sv.js");
const uk_js_1 = require("./uk.js");
/**
 * Registry of all available language configurations
 */
exports.languageRegistry = {
    en: en_js_1.enConfig,
    es: es_js_1.esConfig,
    fr: fr_js_1.frConfig,
    de: de_js_1.deConfig,
    ru: ru_js_1.ruConfig,
    zh: zh_js_1.zhConfig,
    ja: ja_js_1.jaConfig,
    it: it_js_1.itConfig,
    nl: nl_js_1.nlConfig,
    pt: pt_js_1.ptConfig,
    sv: sv_js_1.svConfig,
    uk: uk_js_1.ukConfig,
};
/**
 * Get available languages as options for settings dropdown
 */
function getAvailableLanguages() {
    return Object.values(exports.languageRegistry).map((config) => ({
        value: config.code,
        label: config.name,
    }));
}
/**
 * Get language configuration by code, fallback to English
 */
function getLanguageConfig(languageCode) {
    return exports.languageRegistry[languageCode] || exports.languageRegistry["en"];
}
/**
 * Detect system language and return supported language code
 * Falls back to English if system language is not supported
 */
function detectSystemLanguage() {
    // Try to detect from browser/system locale
    const systemLang = typeof navigator !== "undefined" ? navigator.language?.split("-")[0] : "en";
    // Return system language if supported, otherwise default to English
    return exports.languageRegistry[systemLang] ? systemLang : "en";
}
// Re-export types for convenience
__exportStar(require("./types.js"), exports);
//# sourceMappingURL=index.js.map