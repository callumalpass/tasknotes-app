"use strict";
/**
 * Language configuration for Natural Language Processing
 * Defines patterns and keywords for different languages
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map