"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_NLP_TRIGGERS = void 0;
exports.DEFAULT_NLP_TRIGGERS = {
    triggers: [
        { propertyId: "tags", trigger: "#", enabled: true },
        { propertyId: "contexts", trigger: "@", enabled: true },
        { propertyId: "projects", trigger: "+", enabled: true },
        { propertyId: "status", trigger: "*", enabled: true },
        { propertyId: "priority", trigger: "!", enabled: false },
    ],
};
//# sourceMappingURL=defaults.js.map