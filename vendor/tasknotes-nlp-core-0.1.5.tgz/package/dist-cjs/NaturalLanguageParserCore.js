"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.NaturalLanguageParserCore = void 0;
const date_fns_1 = require("date-fns");
const chrono = __importStar(require("chrono-node"));
const rruleModule = __importStar(require("rrule"));
const index_js_1 = require("./languages/index.js");
const TriggerConfigService_js_1 = require("./TriggerConfigService.js");
const defaults_js_1 = require("./defaults.js");
const RRule = rruleModule.RRule;
class NaturalLanguageParserCore {
    constructor(statusConfigs = [], priorityConfigs = [], defaultToScheduled = true, languageCode = "en", nlpTriggers, userFields, options = {}) {
        this.isValidDateString = (dateString) => /^\d{4}-\d{2}-\d{2}$/.test(dateString);
        this.isValidTimeString = (timeString) => /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/.test(timeString);
        this.escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        /** Cleans up whitespace after text extraction */
        this.cleanupWhitespace = (text) => {
            return text
                .replace(/\s+/g, " ")
                .replace(/^\s+|\s+$/g, "")
                .trim();
        };
        this.defaultToScheduled = defaultToScheduled;
        this.languageConfig = (0, index_js_1.getLanguageConfig)(languageCode);
        this.options = options;
        // Store status configs for string-based matching
        this.statusConfigs = statusConfigs;
        this.priorityConfigs = priorityConfigs;
        // Initialize trigger configuration service
        // If no config provided, use defaults
        const effectiveTriggers = nlpTriggers || defaults_js_1.DEFAULT_NLP_TRIGGERS;
        this.triggerConfig = new TriggerConfigService_js_1.TriggerConfigService(effectiveTriggers, userFields || []);
        // Create boundary configuration once for all pattern building
        this.boundaries = this.createBoundaryConfig();
        // Pre-compile recurrence patterns for performance
        this.recurrencePatterns = this.buildRecurrencePatterns();
        // Initialize the processing pipeline
        this.processingPipeline = this.buildProcessingPipeline();
    }
    /**
     * Creates boundary configuration based on language characteristics.
     * Non-ASCII languages (with accented characters, non-Latin scripts) need flexible boundaries.
     */
    createBoundaryConfig() {
        const isNonAscii = ["ru", "zh", "ja", "uk", "fr"].includes(this.languageConfig.code);
        return {
            boundary: isNonAscii ? "(?:^|\\s)" : "\\b",
            endBoundary: isNonAscii ? "(?=\\s|$)" : "\\b",
            isNonAscii,
        };
    }
    /**
     * Get the appropriate chrono parser for the configured language.
     */
    getChronoParser() {
        const locale = this.languageConfig.chronoLocale;
        return chrono[locale] || chrono;
    }
    /**
     * Build the modular processing pipeline.
     * Each processor is self-contained and operates on the current state.
     */
    buildProcessingPipeline() {
        return [
            {
                name: "extractTags",
                process: (text, result) => this.extractTags(text, result),
            },
            {
                name: "extractContexts",
                process: (text, result) => this.extractContexts(text, result),
            },
            {
                name: "extractProjects",
                process: (text, result) => this.extractProjects(text, result),
            },
            {
                name: "extractPriority",
                process: (text, result) => this.extractPriority(text, result),
            },
            {
                name: "extractStatus",
                process: (text, result) => this.extractStatus(text, result),
            },
            {
                name: "extractRecurrence",
                process: (text, result) => this.extractRecurrence(text, result),
            },
            {
                name: "extractTimeEstimate",
                process: (text, result) => this.extractTimeEstimate(text, result),
            },
            {
                name: "extractUserFields",
                process: (text, result) => this.extractUserFields(text, result),
            },
            {
                name: "parseUnifiedDatesAndTimes",
                process: (text, result) => this.parseUnifiedDatesAndTimes(text, result),
            },
        ];
    }
    /**
     * Parse natural language input into structured task data using a modular pipeline architecture.
     * Each processing stage is self-contained and can be easily reordered, added, or removed.
     */
    parseInput(input) {
        const result = {
            title: "",
            tags: [],
            contexts: [],
            projects: [],
        };
        // 1. Separate title line from details
        const protectedInput = this.protectNlpLiterals(input);
        const normalizedInput = this.normalizeNumericDateLiterals(protectedInput.text);
        const [workingText, details] = this.extractTitleAndDetails(normalizedInput);
        if (details) {
            result.details = details;
        }
        // 2. Run through the processing pipeline
        let remainingText = workingText;
        for (const processor of this.processingPipeline) {
            try {
                remainingText = processor.process(remainingText, result);
            }
            catch (error) {
                console.debug(`Error in processor ${processor.name}:`, error);
                // Continue with other processors even if one fails
            }
        }
        // 3. The remainder is the title
        result.title = remainingText.trim();
        // 4. Validate and finalize the result
        const finalized = this.validateAndCleanupResult(result);
        this.restoreProtectedLiterals(finalized, protectedInput.literals);
        return finalized;
    }
    protectNlpLiterals(input) {
        const structured = this.protectObsidianLinks(input);
        const quoted = this.protectQuotedLiterals(structured.text, structured.literals);
        return this.protectEscapedLiterals(quoted.text, quoted.literals);
    }
    protectObsidianLinks(input) {
        const literals = [];
        let text = "";
        let index = 0;
        while (index < input.length) {
            if (!input.startsWith("[[", index)) {
                text += input[index];
                index += 1;
                continue;
            }
            const endIndex = input.indexOf("]]", index + 2);
            if (endIndex === -1) {
                text += input[index];
                index += 1;
                continue;
            }
            const literal = input.slice(index, endIndex + 2);
            const placeholder = `__TASKNOTES_NLP_LITERAL_${literals.length}__`;
            literals.push(literal);
            text += placeholder;
            index = endIndex + 2;
        }
        return { text, literals };
    }
    protectQuotedLiterals(input, literals = []) {
        let text = "";
        let index = 0;
        while (index < input.length) {
            const char = input[index];
            if (!this.isQuoteDelimiter(char) || !this.isEligibleQuoteStart(input, index)) {
                text += char;
                index += 1;
                continue;
            }
            const endIndex = this.findClosingQuote(input, index + 1, char);
            if (endIndex === -1 || !this.isEligibleQuoteEnd(input, endIndex)) {
                text += char;
                index += 1;
                continue;
            }
            const literal = input.slice(index + 1, endIndex);
            if (literal.trim().length === 0) {
                text += char;
                index += 1;
                continue;
            }
            const placeholder = `__TASKNOTES_NLP_LITERAL_${literals.length}__`;
            literals.push(literal);
            text += placeholder;
            index = endIndex + 1;
        }
        return { text, literals };
    }
    protectEscapedLiterals(input, literals) {
        let text = "";
        let index = 0;
        while (index < input.length) {
            if (input[index] !== "\\") {
                text += input[index];
                index += 1;
                continue;
            }
            const literalStart = index + 1;
            if (literalStart >= input.length ||
                !this.shouldProtectEscapedLiteral(input, index, literalStart)) {
                text += input[index];
                index += 1;
                continue;
            }
            let literalEnd = literalStart;
            while (literalEnd < input.length && !/\s/u.test(input[literalEnd])) {
                literalEnd += 1;
            }
            const literal = input.slice(literalStart, literalEnd);
            const placeholder = `__TASKNOTES_NLP_LITERAL_${literals.length}__`;
            literals.push(literal);
            text += placeholder;
            index = literalEnd;
        }
        return { text, literals };
    }
    restoreProtectedLiterals(parsed, literals) {
        if (literals.length === 0)
            return;
        parsed.title = this.restoreProtectedLiteralsInText(parsed.title, literals)
            .replace(/\s+/g, " ")
            .trim();
        parsed.tags = parsed.tags.map((tag) => this.restoreProtectedLiteralsInText(tag, literals));
        parsed.contexts = parsed.contexts.map((context) => this.restoreProtectedLiteralsInText(context, literals));
        parsed.projects = parsed.projects.map((project) => this.restoreProtectedLiteralsInText(project, literals));
        if (parsed.details) {
            parsed.details = this.restoreProtectedLiteralsInText(parsed.details, literals);
        }
        if (parsed.userFields) {
            for (const [key, value] of Object.entries(parsed.userFields)) {
                if (typeof value === "string") {
                    parsed.userFields[key] = this.restoreProtectedLiteralsInText(value, literals);
                }
                else {
                    parsed.userFields[key] = value.map((item) => this.restoreProtectedLiteralsInText(item, literals));
                }
            }
        }
    }
    restoreProtectedLiteralsInText(text, literals) {
        let restored = text;
        literals.forEach((literal, index) => {
            restored = restored.replace(`__TASKNOTES_NLP_LITERAL_${index}__`, literal);
        });
        return restored;
    }
    isQuoteDelimiter(char) {
        return char === "\"" || char === "'" || char === "`";
    }
    isEligibleQuoteStart(input, index) {
        const char = input[index];
        if (char !== "'")
            return true;
        const previous = index > 0 ? input[index - 1] : "";
        return !this.isWordCharacter(previous);
    }
    isEligibleQuoteEnd(input, index) {
        const char = input[index];
        if (char !== "'")
            return true;
        const next = index + 1 < input.length ? input[index + 1] : "";
        return !this.isWordCharacter(next);
    }
    findClosingQuote(input, startIndex, delimiter) {
        for (let index = startIndex; index < input.length; index += 1) {
            if (input[index] !== delimiter)
                continue;
            const previous = index > 0 ? input[index - 1] : "";
            if (previous === "\\")
                continue;
            return index;
        }
        return -1;
    }
    shouldProtectEscapedLiteral(input, escapeIndex, literalStart) {
        if (this.startsWithEscapableTrigger(input, literalStart)) {
            return true;
        }
        const previous = escapeIndex > 0 ? input[escapeIndex - 1] : "";
        if (previous && !/\s/u.test(previous)) {
            return false;
        }
        return /[\p{L}\p{N}]/u.test(input[literalStart]);
    }
    startsWithEscapableTrigger(input, index) {
        return this.getEscapableTriggers().some((trigger) => input.startsWith(trigger, index));
    }
    getEscapableTriggers() {
        const configured = this.triggerConfig
            .getTriggersOrderedByLength()
            .map((trigger) => trigger.trigger)
            .filter((trigger) => trigger.length > 0);
        return configured.length > 0 ? configured : ["#", "@", "+", "*", "!"];
    }
    normalizeNumericDateLiterals(input) {
        const withYearFirstDates = input.replace(/(^|[^\p{L}\p{N}_])(\d{4})[/.](\d{1,2})[/.](\d{1,2})(?=$|[^\p{L}\p{N}_])/gu, (match, prefix, yearText, monthText, dayText) => {
            const formatted = this.toValidatedISODate(Number(yearText), Number(monthText), Number(dayText));
            return formatted ? `${prefix}${formatted}` : match;
        });
        if (this.getNumericDateOrder() !== "day-first") {
            return withYearFirstDates;
        }
        return withYearFirstDates.replace(/(^|[^\p{L}\p{N}_])(\d{1,2})[/.](\d{1,2})[/.](\d{4})(?=$|[^\p{L}\p{N}_])/gu, (match, prefix, dayText, monthText, yearText) => {
            const formatted = this.toValidatedISODate(Number(yearText), Number(monthText), Number(dayText));
            return formatted ? `${prefix}${formatted}` : match;
        });
    }
    getNumericDateOrder() {
        if (this.options.dateOrder) {
            return this.options.dateOrder;
        }
        const locale = this.options.dateLocale || this.languageConfig.code;
        try {
            const parts = new Intl.DateTimeFormat(locale).formatToParts(new Date(2006, 10, 22));
            const firstDatePart = parts.find((part) => part.type === "day" || part.type === "month" || part.type === "year");
            if (firstDatePart?.type === "day") {
                return "day-first";
            }
        }
        catch {
            // Fall back to month-first, matching chrono's English numeric-date default.
        }
        return "month-first";
    }
    toValidatedISODate(year, month, day) {
        const parsed = new Date(Date.UTC(year, month - 1, day));
        if (parsed.getUTCFullYear() !== year ||
            parsed.getUTCMonth() !== month - 1 ||
            parsed.getUTCDate() !== day) {
            return null;
        }
        return `${year}-${this.padDatePart(month)}-${this.padDatePart(day)}`;
    }
    padDatePart(value) {
        return String(value).padStart(2, "0");
    }
    /**
     * Splits the input string into the first line (for parsing) and the rest (for details).
     */
    extractTitleAndDetails(input) {
        const trimmedInput = input.trim();
        const firstLineBreak = trimmedInput.indexOf("\n");
        if (firstLineBreak !== -1) {
            const titleLine = trimmedInput.substring(0, firstLineBreak).trim();
            const details = trimmedInput.substring(firstLineBreak + 1).trim();
            return [titleLine, details];
        }
        return [trimmedInput, undefined];
    }
    /** Extracts tags from the text and adds them to the result object. */
    extractTags(text, result) {
        const trigger = this.triggerConfig.getTagTrigger();
        if (!trigger)
            return text; // Tags disabled
        const escapedTrigger = this.escapeRegex(trigger);
        // Use Unicode-aware pattern to support non-ASCII characters (accented, Cyrillic, CJK, etc.)
        const tagPattern = new RegExp(`${escapedTrigger}[\\p{L}\\p{N}\\p{M}_/-]+`, "gu");
        const tagMatches = text.match(tagPattern);
        if (tagMatches) {
            result.tags.push(...tagMatches.map((tag) => tag.substring(trigger.length)));
            return this.cleanupWhitespace(text.replace(tagPattern, ""));
        }
        return text;
    }
    /** Extracts contexts from the text and adds them to the result object. */
    extractContexts(text, result) {
        const trigger = this.triggerConfig.getContextTrigger();
        if (!trigger)
            return text; // Contexts disabled
        const escapedTrigger = this.escapeRegex(trigger);
        // Use Unicode-aware pattern to support non-ASCII characters (accented, Cyrillic, CJK, etc.)
        const contextPattern = new RegExp(`${escapedTrigger}[\\p{L}\\p{N}\\p{M}_/-]+`, "gu");
        const contextMatches = text.match(contextPattern);
        if (contextMatches) {
            result.contexts.push(...contextMatches.map((context) => context.substring(trigger.length)));
            return this.cleanupWhitespace(text.replace(contextPattern, ""));
        }
        return text;
    }
    /** Extracts projects and [[wikilinks]] from the text and adds them to the result object. */
    extractProjects(text, result) {
        const trigger = this.triggerConfig.getProjectTrigger();
        if (!trigger)
            return text; // Projects disabled
        let workingText = text;
        const escapedTrigger = this.escapeRegex(trigger);
        // Extract trigger[[wikilink]] patterns first (more specific)
        const wikilinkPattern = new RegExp(`${escapedTrigger}\\[\\[.*?\\]\\]`, "g");
        const wikilinkProjectMatches = workingText.match(wikilinkPattern);
        if (wikilinkProjectMatches) {
            result.projects.push(...wikilinkProjectMatches.map((project) => {
                // Remove the trigger prefix but keep [[ ]]
                let projectName = project.slice(trigger.length); // Remove just the trigger
                // Keep the full wikilink as-is for now - resolution will happen in InstantTaskConvertService
                return projectName;
            }));
            workingText = this.cleanupWhitespace(workingText.replace(wikilinkPattern, ""));
        }
        // Extract simple word projects
        // Use Unicode-aware pattern to support non-ASCII characters (accented, Cyrillic, CJK, etc.)
        const projectPattern = new RegExp(`${escapedTrigger}[\\p{L}\\p{N}\\p{M}_/-]+`, "gu");
        const projectMatches = workingText.match(projectPattern);
        if (projectMatches) {
            result.projects.push(...projectMatches.map((project) => project.substring(trigger.length)));
            workingText = this.cleanupWhitespace(workingText.replace(projectPattern, ""));
        }
        return workingText;
    }
    /**
     * Extracts user-defined field values from the text
     * Supports quoted values for multi-word content: trigger "multi word value"
     */
    extractUserFields(text, result) {
        let workingText = text;
        // Get all enabled user field triggers
        const userFieldTriggers = this.triggerConfig
            .getAllEnabledTriggers()
            .filter((t) => this.triggerConfig.isUserField(t.propertyId));
        // Process each user field trigger
        for (const triggerDef of userFieldTriggers) {
            const userField = this.triggerConfig.getUserField(triggerDef.propertyId);
            if (!userField) {
                continue;
            }
            const escapedTrigger = this.escapeRegex(triggerDef.trigger);
            // For list fields, extract multiple values (supports quoted multi-word values)
            if (userField.type === "list") {
                // Match trigger followed by either:
                // 1. Quoted string: "anything inside quotes"
                // 2. Single/double word: word or word-with-dash (Unicode-aware)
                const pattern = new RegExp(`${escapedTrigger}(?:"([^"]+)"|([\\p{L}\\p{N}\\p{M}_/-]+))`, "gu");
                const values = [];
                let match;
                while ((match = pattern.exec(workingText)) !== null) {
                    // Group 1 is quoted value, Group 2 is unquoted value
                    const value = match[1] || match[2];
                    values.push(value);
                }
                if (values.length > 0) {
                    if (!result.userFields)
                        result.userFields = {};
                    result.userFields[userField.id] = values;
                    workingText = this.cleanupWhitespace(workingText.replace(pattern, ""));
                }
            }
            // For text/boolean/number fields, extract single value (supports quoted multi-word)
            else if (userField.type === "text" || userField.type === "boolean" || userField.type === "number") {
                // Match trigger followed by either:
                // 1. Quoted string: "anything inside quotes"
                // 2. Single word: word or word-with-dash (Unicode-aware)
                const pattern = new RegExp(`${escapedTrigger}(?:"([^"]+)"|([\\p{L}\\p{N}\\p{M}_/-]+))`, "u");
                const match = workingText.match(pattern);
                if (match) {
                    // Group 1 is quoted value, Group 2 is unquoted value
                    const value = match[1] || match[2];
                    if (!result.userFields)
                        result.userFields = {};
                    // Convert to boolean if needed
                    if (userField.type === "boolean") {
                        result.userFields[userField.id] =
                            value.toLowerCase() === "true" ? "true" : "false";
                    }
                    else {
                        result.userFields[userField.id] = value;
                    }
                    workingText = this.cleanupWhitespace(workingText.replace(pattern, ""));
                }
            }
            // For date fields, try to parse as date (supports quoted values too)
            else if (userField.type === "date") {
                // Match trigger followed by either quoted or unquoted date-like pattern (Unicode-aware)
                const pattern = new RegExp(`${escapedTrigger}(?:"([^"]+)"|([\\p{L}\\p{N}\\p{M}_/-]+))`, "u");
                const match = workingText.match(pattern);
                if (match) {
                    const value = match[1] || match[2];
                    if (!result.userFields)
                        result.userFields = {};
                    result.userFields[userField.id] = value; // Store as-is, let consuming code parse
                    workingText = this.cleanupWhitespace(workingText.replace(pattern, ""));
                }
            }
        }
        return workingText;
    }
    /** Extracts priority using shared phrase matching for custom and fallback priorities. */
    extractPriority(text, result) {
        if (this.priorityConfigs.length > 0) {
            const sortedConfigs = [...this.priorityConfigs].sort((a, b) => b.label.length - a.label.length);
            const priorityTrigger = this.triggerConfig.getTriggerForProperty("priority");
            const trigger = priorityTrigger?.enabled ? priorityTrigger.trigger : "";
            for (const config of sortedConfigs) {
                const candidates = [config.label, config.value];
                for (const candidate of candidates) {
                    if (!candidate || candidate.trim() === "")
                        continue;
                    // 1. Try trigger + candidate
                    if (trigger) {
                        const triggerPlusCandidate = trigger + candidate;
                        const match = this.findTextMatch(text, triggerPlusCandidate);
                        if (match) {
                            result.priority = config.value;
                            return this.cleanupWhitespace(text.replace(match.fullMatch, ""));
                        }
                    }
                    // 2. Fallback: candidate only
                    const match = this.findTextMatch(text, candidate);
                    if (match) {
                        result.priority = config.value;
                        return this.cleanupWhitespace(text.replace(match.fullMatch, ""));
                    }
                }
            }
            return text;
        }
        const langConfig = this.languageConfig.fallbackPriority;
        const match = this.findPhraseValueMatch(text, [
            { value: "urgent", phrases: langConfig.urgent },
            { value: "high", phrases: langConfig.high },
            { value: "normal", phrases: langConfig.normal },
            { value: "low", phrases: langConfig.low },
        ]);
        if (match) {
            result.priority = match.value;
            return this.removePhraseMatch(text, match.match);
        }
        return text;
    }
    /** Extracts status using shared phrase matching for custom and fallback statuses. */
    extractStatus(text, result) {
        // If user has defined custom status configs, only use those
        if (this.statusConfigs.length > 0) {
            // Sort by length (longest first) to prevent partial matches
            const sortedConfigs = [...this.statusConfigs].sort((a, b) => b.label.length - a.label.length);
            const statusTrigger = this.triggerConfig.getTriggerForProperty("status");
            const trigger = statusTrigger?.enabled ? statusTrigger.trigger : "";
            for (const config of sortedConfigs) {
                // Try both label and value
                const candidates = [config.label, config.value];
                for (const candidate of candidates) {
                    // Skip empty candidates
                    if (!candidate || candidate.trim() === "") {
                        continue;
                    }
                    // 1. Try to find trigger + candidate first (if trigger exists)
                    if (trigger) {
                        const triggerPlusCandidate = trigger + candidate;
                        const match = this.findTextMatch(text, triggerPlusCandidate);
                        if (match) {
                            result.status = config.value;
                            return this.cleanupWhitespace(text.replace(match.fullMatch, ""));
                        }
                    }
                    // 2. Fallback: Try to find just the candidate (backward compatibility / autocomplete)
                    const match = this.findTextMatch(text, candidate);
                    if (match) {
                        result.status = config.value;
                        return this.cleanupWhitespace(text.replace(match.fullMatch, ""));
                    }
                }
            }
            // If user has custom configs but no match found, return without setting status
            return text;
        }
        const langConfig = this.languageConfig.fallbackStatus;
        const match = this.findPhraseValueMatch(text, [
            { value: "open", phrases: langConfig.open },
            { value: "in-progress", phrases: langConfig.inProgress },
            { value: "done", phrases: langConfig.done },
            { value: "cancelled", phrases: langConfig.cancelled },
            { value: "waiting", phrases: langConfig.waiting },
        ]);
        if (match) {
            result.status = match.value;
            return this.removePhraseMatch(text, match.match);
        }
        return text;
    }
    /**
     * Finds a match using case-insensitive string search with boundary checking.
     * Returns the match details or null if no valid match found.
     */
    findTextMatch(text, searchText) {
        const match = this.findPhraseMatch(text, [searchText]);
        if (!match) {
            return null;
        }
        const fullMatchEndIndex = this.includeTrailingPhraseSeparator(text, match.endIndex);
        return {
            fullMatch: text.substring(match.startIndex, fullMatchEndIndex),
            startIndex: match.startIndex,
        };
    }
    /**
     * Finds the earliest whole-phrase match, preferring the longest phrase at the same position.
     */
    findPhraseMatch(text, phrases) {
        const searchablePhrases = phrases
            .filter((phrase) => phrase && phrase.trim() !== "")
            .sort((a, b) => b.length - a.length);
        if (searchablePhrases.length === 0) {
            return null;
        }
        const lowerText = text.toLowerCase();
        let bestMatch = null;
        for (const phrase of searchablePhrases) {
            const lowerPhrase = phrase.toLowerCase();
            let searchIndex = 0;
            while (searchIndex <= lowerText.length) {
                const index = lowerText.indexOf(lowerPhrase, searchIndex);
                if (index === -1) {
                    break;
                }
                const endIndex = index + phrase.length;
                if (this.hasPhraseBoundaries(text, index, endIndex)) {
                    const candidate = {
                        fullMatch: text.substring(index, endIndex),
                        phrase,
                        startIndex: index,
                        endIndex,
                    };
                    if (!bestMatch ||
                        candidate.startIndex < bestMatch.startIndex ||
                        (candidate.startIndex === bestMatch.startIndex &&
                            candidate.phrase.length > bestMatch.phrase.length)) {
                        bestMatch = candidate;
                    }
                }
                searchIndex = index + 1;
            }
        }
        return bestMatch;
    }
    findPhraseValueMatch(text, groups) {
        let bestMatch = null;
        for (const group of groups) {
            const match = this.findPhraseMatch(text, group.phrases);
            if (match &&
                (!bestMatch ||
                    match.startIndex < bestMatch.match.startIndex ||
                    (match.startIndex === bestMatch.match.startIndex &&
                        match.phrase.length > bestMatch.match.phrase.length))) {
                bestMatch = { value: group.value, match };
            }
        }
        return bestMatch;
    }
    removePhraseMatch(text, match) {
        const endIndex = this.includeTrailingPhraseSeparator(text, match.endIndex);
        return this.cleanupWhitespace(text.substring(0, match.startIndex) + text.substring(endIndex));
    }
    hasPhraseBoundaries(text, startIndex, endIndex) {
        if (["zh", "ja"].includes(this.languageConfig.code)) {
            return true;
        }
        const beforeChar = this.getCodePointBefore(text, startIndex);
        const afterChar = this.getCodePointAt(text, endIndex);
        return !this.isWordCharacter(beforeChar) && !this.isWordCharacter(afterChar);
    }
    getCodePointBefore(text, index) {
        if (index <= 0) {
            return "";
        }
        return Array.from(text.slice(0, index)).pop() || "";
    }
    getCodePointAt(text, index) {
        if (index >= text.length) {
            return "";
        }
        return Array.from(text.slice(index))[0] || "";
    }
    isWordCharacter(char) {
        return char !== "" && /[\p{L}\p{N}\p{M}_]/u.test(char);
    }
    includeTrailingPhraseSeparator(text, endIndex) {
        return /[:,;]/.test(text[endIndex] || "") ? endIndex + 1 : endIndex;
    }
    /**
     * Unified method to parse all dates and times with internationalized context awareness.
     * Combines the functionality of extractExplicitDates and parseDatesAndTimes.
     *
     * Processing order:
     * 1. Look for explicit trigger patterns: "due tomorrow", "scheduled for friday"
     * 2. Parse implicit dates using chrono-node with language-specific parser
     * 3. Determine if date is due/scheduled based on context and defaultToScheduled setting
     *
     * Trigger pattern examples:
     * - English: "due\s+", "scheduled\s+for"
     * - French: "échéance\s+", "programmé\s+pour"
     * - German: "fällig\s+am", "geplant\s+für"
     *
     * @param text Input text to parse
     * @param result ParsedTaskData object to populate with date/time fields
     * @returns Text with date/time patterns removed
     */
    parseUnifiedDatesAndTimes(text, result) {
        let workingText = text;
        try {
            const chronoParser = this.getChronoParser();
            const langTriggers = this.languageConfig.dateTriggers;
            // First, try to find explicit trigger phrases.
            const triggerPatterns = [
                {
                    type: "due",
                    phrases: langTriggers.due,
                },
                {
                    type: "scheduled",
                    phrases: langTriggers.scheduled,
                },
            ];
            // Check for explicit triggers - process all triggers, not just the first one
            let foundExplicitTrigger = false;
            for (const triggerPattern of triggerPatterns) {
                const match = this.findPhraseMatch(workingText, triggerPattern.phrases);
                if (match) {
                    // Get the position where the date text starts (after the trigger)
                    const remainingText = workingText.substring(match.endIndex);
                    // Use chrono-node to parse from this position onward
                    const chronoParsed = this.parseChronoFromPosition(remainingText);
                    if (chronoParsed.success) {
                        foundExplicitTrigger = true;
                        // Assign to the correct field based on trigger type
                        if (triggerPattern.type === "due") {
                            result.dueDate = chronoParsed.date;
                            if (chronoParsed.time) {
                                result.dueTime = chronoParsed.time;
                            }
                        }
                        else {
                            result.scheduledDate = chronoParsed.date;
                            if (chronoParsed.time) {
                                result.scheduledTime = chronoParsed.time;
                            }
                        }
                        // Remove the entire matched expression (trigger + connector text + date).
                        const remainingDateOffset = this.getChronoMatchOffset(remainingText, chronoParsed);
                        const dateEnd = chronoParsed.matchedText
                            ? match.endIndex + remainingDateOffset + chronoParsed.matchedText.length
                            : match.endIndex;
                        workingText =
                            workingText.substring(0, match.startIndex) + workingText.substring(dateEnd);
                        workingText = this.cleanupWhitespace(workingText);
                        // Continue processing to find additional triggers (Issue #1421)
                    }
                }
            }
            // Return early if we found explicit triggers - no need for implicit parsing
            if (foundExplicitTrigger) {
                return workingText;
            }
            // If no explicit triggers found, parse all remaining dates with context
            const parsedResults = chronoParser.parse(text, new Date(), { forwardDate: true });
            if (parsedResults.length === 0) {
                return text;
            }
            const primaryMatch = parsedResults[0];
            const dateText = primaryMatch.text;
            const startDate = primaryMatch.start.date();
            const endDate = primaryMatch.end?.date();
            let isDue = this.findPhraseMatch(primaryMatch.text, langTriggers.due) !== null;
            let isScheduled = this.findPhraseMatch(primaryMatch.text, langTriggers.scheduled) !== null;
            // Handle date ranges (e.g., "from tomorrow to next friday")
            if (endDate && (0, date_fns_1.isValid)(endDate) && endDate.getTime() !== startDate.getTime()) {
                result.scheduledDate = (0, date_fns_1.format)(startDate, "yyyy-MM-dd");
                if (primaryMatch.start.isCertain("hour")) {
                    result.scheduledTime = (0, date_fns_1.format)(startDate, "HH:mm");
                }
                result.dueDate = (0, date_fns_1.format)(endDate, "yyyy-MM-dd");
                if (primaryMatch.end?.isCertain("hour")) {
                    result.dueTime = (0, date_fns_1.format)(endDate, "HH:mm");
                }
            }
            // Handle single dates
            else if ((0, date_fns_1.isValid)(startDate)) {
                const dateString = (0, date_fns_1.format)(startDate, "yyyy-MM-dd");
                const timeString = primaryMatch.start.isCertain("hour")
                    ? (0, date_fns_1.format)(startDate, "HH:mm")
                    : undefined;
                // Prioritize explicit keywords, otherwise use default setting
                if (isDue && !isScheduled) {
                    result.dueDate = dateString;
                    result.dueTime = timeString;
                }
                else if (isScheduled && !isDue) {
                    result.scheduledDate = dateString;
                    result.scheduledTime = timeString;
                }
                else if (this.defaultToScheduled) {
                    result.scheduledDate = dateString;
                    result.scheduledTime = timeString;
                }
                else {
                    result.dueDate = dateString;
                    result.dueTime = timeString;
                }
            }
            // Remove the date text from the working text
            workingText = workingText.replace(dateText, "").trim();
            workingText = this.cleanupWhitespace(workingText);
        }
        catch (error) {
            console.debug("Error in unified date parsing:", error);
        }
        return workingText;
    }
    /**
     * Use chrono-node to parse date starting from a specific position.
     * Uses language-specific chrono parser and validates that match starts near beginning.
     *
     * Position validation: Match must start within first 3 characters to account for
     * prepositions like "on", "at", "le", "am" in different languages.
     *
     * @param text Text to parse (typically after a trigger word)
     * @returns Parsed date result with success flag, formatted date/time, and matched text
     */
    parseChronoFromPosition(text) {
        try {
            // Parse the text starting from the beginning using locale-specific parser
            const chronoParser = this.getChronoParser();
            const parsed = chronoParser.parse(text, new Date(), { forwardDate: true });
            if (parsed.length > 0) {
                const firstMatch = parsed[0];
                // Ensure the match starts at or near the beginning of the text
                if (firstMatch.index <= 3) {
                    // Allow for a few characters of whitespace/prepositions
                    const parsedDate = firstMatch.start.date();
                    if ((0, date_fns_1.isValid)(parsedDate)) {
                        const result = {
                            success: true,
                            date: (0, date_fns_1.format)(parsedDate, "yyyy-MM-dd"),
                            matchedText: firstMatch.text,
                            startIndex: firstMatch.index,
                        };
                        // Check if time is included and certain
                        if (firstMatch.start.isCertain("hour")) {
                            result.time = (0, date_fns_1.format)(parsedDate, "HH:mm");
                        }
                        return result;
                    }
                }
            }
        }
        catch (error) {
            console.debug("Error parsing date with chrono:", error);
        }
        return { success: false };
    }
    getChronoMatchOffset(text, chronoParsed) {
        const reportedStart = chronoParsed.startIndex ?? 0;
        if (!chronoParsed.matchedText) {
            return reportedStart;
        }
        const actualStart = text.indexOf(chronoParsed.matchedText);
        if (actualStart !== -1) {
            return actualStart;
        }
        return reportedStart;
    }
    /**
     * Builds comprehensive recurrence patterns from language configuration.
     * Patterns are ordered by priority (most specific first) and cached for performance.
     */
    buildRecurrencePatterns() {
        const lang = this.languageConfig.recurrence;
        const patterns = [];
        // Use pre-configured boundary matching
        const { boundary, endBoundary } = this.boundaries;
        // Helper function to escape and join patterns
        const escapeAndJoin = (patterns) => patterns.map((p) => this.escapeRegex(p)).join("|");
        // Build patterns in priority order (most specific first)
        patterns.push(...this.buildOrdinalWeekdayPatterns(lang, boundary, endBoundary, escapeAndJoin));
        patterns.push(...this.buildIntervalPatterns(lang, boundary, endBoundary, escapeAndJoin));
        patterns.push(...this.buildEveryOtherPatterns(lang, boundary, endBoundary, escapeAndJoin));
        patterns.push(...this.buildWeekdayPatterns(lang, boundary, endBoundary, escapeAndJoin));
        patterns.push(...this.buildFrequencyPatterns(lang, boundary, endBoundary, escapeAndJoin));
        return patterns;
    }
    /**
     * Builds "every [ordinal] [weekday]" patterns (e.g., "every second monday").
     * These have highest priority as they are most specific.
     */
    buildOrdinalWeekdayPatterns(lang, boundary, endBoundary, escapeAndJoin) {
        const everyKeywords = escapeAndJoin(lang.every);
        const ordinalPatterns = escapeAndJoin([
            ...lang.ordinals.first,
            ...lang.ordinals.second,
            ...lang.ordinals.third,
            ...lang.ordinals.fourth,
            ...lang.ordinals.last,
        ]);
        const weekdayPatterns = escapeAndJoin([
            ...lang.weekdays.monday,
            ...lang.weekdays.tuesday,
            ...lang.weekdays.wednesday,
            ...lang.weekdays.thursday,
            ...lang.weekdays.friday,
            ...lang.weekdays.saturday,
            ...lang.weekdays.sunday,
        ]);
        return [
            {
                regex: new RegExp(`${boundary}(${everyKeywords})\\s+(${ordinalPatterns})\\s+(${weekdayPatterns})${endBoundary}`, "i"),
                handler: (match) => {
                    const ordinalText = match[2].toLowerCase();
                    const dayText = match[3].toLowerCase();
                    // Find ordinal position
                    let position = 1;
                    if (lang.ordinals.second.some((o) => o.toLowerCase() === ordinalText))
                        position = 2;
                    else if (lang.ordinals.third.some((o) => o.toLowerCase() === ordinalText))
                        position = 3;
                    else if (lang.ordinals.fourth.some((o) => o.toLowerCase() === ordinalText))
                        position = 4;
                    else if (lang.ordinals.last.some((o) => o.toLowerCase() === ordinalText))
                        position = -1;
                    // Find weekday
                    const rruleDay = this.getWeekdayRRuleCode(dayText, lang);
                    return `FREQ=MONTHLY;BYDAY=${rruleDay};BYSETPOS=${position}`;
                },
            },
        ];
    }
    /**
     * Builds "every [N] [period]" patterns (e.g., "every 3 days", "every 2 weeks").
     */
    buildIntervalPatterns(lang, boundary, endBoundary, escapeAndJoin) {
        const everyKeywords = escapeAndJoin(lang.every);
        const periodPatterns = escapeAndJoin([
            ...lang.periods.day,
            ...lang.periods.week,
            ...lang.periods.month,
            ...lang.periods.year,
        ]);
        return [
            {
                regex: new RegExp(`${boundary}(${everyKeywords})\\s+(\\d+)\\s+(${periodPatterns})${endBoundary}`, "i"),
                handler: (match) => {
                    const interval = parseInt(match[2]);
                    const periodText = match[3].toLowerCase();
                    const freq = this.getPeriodFrequency(periodText, lang);
                    return `FREQ=${freq};INTERVAL=${interval}`;
                },
            },
        ];
    }
    /**
     * Builds "every other [period]" patterns (e.g., "every other week").
     */
    buildEveryOtherPatterns(lang, boundary, endBoundary, escapeAndJoin) {
        const everyKeywords = escapeAndJoin(lang.every);
        const otherKeywords = escapeAndJoin(lang.other);
        const periodPatterns = escapeAndJoin([
            ...lang.periods.day,
            ...lang.periods.week,
            ...lang.periods.month,
            ...lang.periods.year,
        ]);
        return [
            {
                regex: new RegExp(`${boundary}(${everyKeywords})\\s+(${otherKeywords})\\s+(${periodPatterns})${endBoundary}`, "i"),
                handler: (match) => {
                    const periodText = match[3].toLowerCase();
                    const freq = this.getPeriodFrequency(periodText, lang);
                    return `FREQ=${freq};INTERVAL=2`;
                },
            },
        ];
    }
    /**
     * Builds weekday patterns ("every [weekday]" and plural weekdays).
     */
    buildWeekdayPatterns(lang, boundary, endBoundary, escapeAndJoin) {
        const everyKeywords = escapeAndJoin(lang.every);
        const weekdayPatterns = escapeAndJoin([
            ...lang.weekdays.monday,
            ...lang.weekdays.tuesday,
            ...lang.weekdays.wednesday,
            ...lang.weekdays.thursday,
            ...lang.weekdays.friday,
            ...lang.weekdays.saturday,
            ...lang.weekdays.sunday,
        ]);
        const pluralWeekdayPatterns = escapeAndJoin([
            ...lang.pluralWeekdays.monday,
            ...lang.pluralWeekdays.tuesday,
            ...lang.pluralWeekdays.wednesday,
            ...lang.pluralWeekdays.thursday,
            ...lang.pluralWeekdays.friday,
            ...lang.pluralWeekdays.saturday,
            ...lang.pluralWeekdays.sunday,
        ]);
        return [
            // "every [weekday]" patterns
            {
                regex: new RegExp(`${boundary}(${everyKeywords})\\s+(${weekdayPatterns})${endBoundary}`, "i"),
                handler: (match) => {
                    const dayText = match[2].toLowerCase();
                    const rruleDay = this.getWeekdayRRuleCode(dayText, lang);
                    return `FREQ=WEEKLY;BYDAY=${rruleDay}`;
                },
            },
            // Plural weekdays ("mondays", "tuesdays")
            {
                regex: new RegExp(`${boundary}(${pluralWeekdayPatterns})${endBoundary}`, "i"),
                handler: (match) => {
                    const dayText = match[1].toLowerCase();
                    const rruleDay = this.getPluralWeekdayRRuleCode(dayText, lang);
                    return `FREQ=WEEKLY;BYDAY=${rruleDay}`;
                },
            },
        ];
    }
    /**
     * Builds general frequency patterns (daily, weekly, monthly, yearly).
     */
    buildFrequencyPatterns(lang, boundary, endBoundary, escapeAndJoin) {
        return [
            {
                regex: new RegExp(`${boundary}(${escapeAndJoin(lang.frequencies.daily)})${endBoundary}`, "i"),
                handler: () => "FREQ=DAILY",
            },
            {
                regex: new RegExp(`${boundary}(${escapeAndJoin(lang.frequencies.weekly)})${endBoundary}`, "i"),
                handler: () => "FREQ=WEEKLY",
            },
            {
                regex: new RegExp(`${boundary}(${escapeAndJoin(lang.frequencies.monthly)})${endBoundary}`, "i"),
                handler: () => "FREQ=MONTHLY",
            },
            {
                regex: new RegExp(`${boundary}(${escapeAndJoin(lang.frequencies.yearly)})${endBoundary}`, "i"),
                handler: () => "FREQ=YEARLY",
            },
        ];
    }
    /**
     * Helper to determine frequency type from period text.
     */
    getPeriodFrequency(periodText, lang) {
        if (lang.periods.week.some((p) => p.toLowerCase() === periodText))
            return "WEEKLY";
        if (lang.periods.month.some((p) => p.toLowerCase() === periodText))
            return "MONTHLY";
        if (lang.periods.year.some((p) => p.toLowerCase() === periodText))
            return "YEARLY";
        return "DAILY"; // default
    }
    /**
     * Helper to get RRule weekday code from weekday text.
     */
    getWeekdayRRuleCode(dayText, lang) {
        if (lang.weekdays.tuesday.some((d) => d.toLowerCase() === dayText))
            return "TU";
        if (lang.weekdays.wednesday.some((d) => d.toLowerCase() === dayText))
            return "WE";
        if (lang.weekdays.thursday.some((d) => d.toLowerCase() === dayText))
            return "TH";
        if (lang.weekdays.friday.some((d) => d.toLowerCase() === dayText))
            return "FR";
        if (lang.weekdays.saturday.some((d) => d.toLowerCase() === dayText))
            return "SA";
        if (lang.weekdays.sunday.some((d) => d.toLowerCase() === dayText))
            return "SU";
        return "MO"; // default to Monday
    }
    /**
     * Helper to get RRule weekday code from plural weekday text.
     */
    getPluralWeekdayRRuleCode(dayText, lang) {
        if (lang.pluralWeekdays.tuesday.some((d) => d.toLowerCase() === dayText))
            return "TU";
        if (lang.pluralWeekdays.wednesday.some((d) => d.toLowerCase() === dayText))
            return "WE";
        if (lang.pluralWeekdays.thursday.some((d) => d.toLowerCase() === dayText))
            return "TH";
        if (lang.pluralWeekdays.friday.some((d) => d.toLowerCase() === dayText))
            return "FR";
        if (lang.pluralWeekdays.saturday.some((d) => d.toLowerCase() === dayText))
            return "SA";
        if (lang.pluralWeekdays.sunday.some((d) => d.toLowerCase() === dayText))
            return "SU";
        return "MO"; // default to Monday
    }
    /**
     * Extracts recurrence from text and generates rrule strings using cached language-aware patterns.
     * All patterns are internationalized and sourced from language configurations.
     */
    extractRecurrence(text, result) {
        for (const pattern of this.recurrencePatterns) {
            const match = text.match(pattern.regex);
            if (match) {
                const rruleString = pattern.handler(match);
                // Validate the rrule string before setting it
                if (this.isValidRRuleString(rruleString)) {
                    result.recurrence = rruleString;
                    return this.cleanupWhitespace(text.replace(pattern.regex, ""));
                }
            }
        }
        return text;
    }
    /**
     * Validate an rrule string to prevent parsing errors
     */
    isValidRRuleString(rruleString) {
        // Check for empty or undefined BYDAY values
        if (rruleString.includes("BYDAY=undefined") ||
            rruleString.includes("BYDAY=;") ||
            rruleString.includes("BYDAY=")) {
            const byDayMatch = rruleString.match(/BYDAY=([^;]*)/);
            if (byDayMatch &&
                (!byDayMatch[1] || byDayMatch[1] === "undefined" || byDayMatch[1].trim() === "")) {
                return false;
            }
        }
        // Check for basic FREQ requirement
        if (!rruleString.includes("FREQ=")) {
            return false;
        }
        return true;
    }
    /**
     * Extracts time estimate from text using language-aware patterns.
     * Supports combined formats (1h30m), hours only (2hrs), and minutes only (45min).
     *
     * Pattern examples:
     * - Combined: "2h 30m" → 150 minutes
     * - Hours: "3 hours" → 180 minutes
     * - Minutes: "45 minutes" → 45 minutes
     *
     * @param text Input text to parse
     * @param result ParsedTaskData object to populate
     * @returns Text with time estimate patterns removed
     */
    extractTimeEstimate(text, result) {
        const langConfig = this.languageConfig.timeEstimate;
        // Use pre-configured boundary matching
        const { boundary, endBoundary } = this.boundaries;
        const patterns = [
            // Combined format: 1h30m
            {
                regex: new RegExp(`${boundary}(\\d+)(${langConfig.hours.map((p) => this.escapeRegex(p)).join("|")})\\s*(\\d+)(${langConfig.minutes.map((p) => this.escapeRegex(p)).join("|")})${endBoundary}`, "i"),
                handler: (m) => parseInt(m[1]) * 60 + parseInt(m[3]),
            },
            // Hours: 1hr, 2 hours, 3h
            {
                regex: new RegExp(`${boundary}(\\d+)\\s*(${langConfig.hours.map((p) => this.escapeRegex(p)).join("|")})${endBoundary}`, "i"),
                handler: (m) => parseInt(m[1]) * 60,
            },
            // Minutes: 30min, 45 m, 15 minutes
            {
                regex: new RegExp(`${boundary}(\\d+)\\s*(${langConfig.minutes.map((p) => this.escapeRegex(p)).join("|")})${endBoundary}`, "i"),
                handler: (m) => parseInt(m[1]),
            },
        ];
        let workingText = text;
        let totalEstimate = 0;
        for (const pattern of patterns) {
            const match = workingText.match(pattern.regex);
            if (match) {
                totalEstimate += pattern.handler(match);
                workingText = this.cleanupWhitespace(workingText.replace(pattern.regex, ""));
            }
        }
        if (totalEstimate > 0) {
            result.estimate = totalEstimate;
        }
        return workingText;
    }
    /**
     * Ensures the final parsed data is valid and clean.
     */
    validateAndCleanupResult(result) {
        // If title becomes empty after parsing, use a default
        if (!result.title.trim()) {
            result.title = "Untitled Task";
        }
        // Sanitize and remove duplicates from arrays
        result.tags = [...new Set(result.tags.filter(Boolean))];
        result.contexts = [...new Set(result.contexts.filter(Boolean))];
        result.projects = [...new Set(result.projects.filter(Boolean))];
        // Ensure date and time strings are valid formats (defensive check)
        if (result.dueDate && !this.isValidDateString(result.dueDate))
            delete result.dueDate;
        if (result.scheduledDate && !this.isValidDateString(result.scheduledDate))
            delete result.scheduledDate;
        if (result.dueTime && !this.isValidTimeString(result.dueTime))
            delete result.dueTime;
        if (result.scheduledTime && !this.isValidTimeString(result.scheduledTime))
            delete result.scheduledTime;
        return result;
    }
    /**
     * Generates a user-friendly preview of the parsed data.
     * Icons are placeholders for the UI layer to interpret.
     */
    getPreviewData(parsed) {
        const parts = [];
        if (parsed.title)
            parts.push({ icon: "edit-3", text: `"${parsed.title}"` });
        if (parsed.details)
            parts.push({
                icon: "file-text",
                text: `Details: "${parsed.details.substring(0, 50)}${parsed.details.length > 50 ? "..." : ""}"`,
            });
        if (parsed.dueDate) {
            const dateStr = parsed.dueTime
                ? `${parsed.dueDate} at ${parsed.dueTime}`
                : parsed.dueDate;
            parts.push({ icon: "calendar", text: `Due: ${dateStr}` });
        }
        if (parsed.scheduledDate) {
            const dateStr = parsed.scheduledTime
                ? `${parsed.scheduledDate} at ${parsed.scheduledTime}`
                : parsed.scheduledDate;
            parts.push({ icon: "calendar-clock", text: `Scheduled: ${dateStr}` });
        }
        if (parsed.priority)
            parts.push({ icon: "alert-triangle", text: `Priority: ${parsed.priority}` });
        if (parsed.status)
            parts.push({ icon: "activity", text: `Status: ${parsed.status}` });
        if (parsed.contexts && parsed.contexts.length > 0)
            parts.push({
                icon: "map-pin",
                text: `Contexts: ${parsed.contexts.map((c) => "@" + c).join(", ")}`,
            });
        if (parsed.projects && parsed.projects.length > 0) {
            // Display projects with + prefix (no need to wrap in brackets - just show what was parsed)
            const projectDisplay = parsed.projects.map((p) => `+${p}`).join(", ");
            parts.push({ icon: "folder", text: `Projects: ${projectDisplay}` });
        }
        if (parsed.tags && parsed.tags.length > 0)
            parts.push({
                icon: "tag",
                text: `Tags: ${parsed.tags.map((t) => "#" + t).join(", ")}`,
            });
        if (parsed.recurrence) {
            let recurrenceText = "Invalid recurrence";
            try {
                // Ensure it's a valid RRule before trying to parse
                if (parsed.recurrence.includes("FREQ=") &&
                    this.isValidRRuleString(parsed.recurrence)) {
                    recurrenceText = RRule.fromString(parsed.recurrence).toText();
                }
            }
            catch (error) {
                console.debug("Error parsing rrule for preview:", error);
            }
            parts.push({ icon: "repeat", text: `Recurrence: ${recurrenceText}` });
        }
        if (parsed.estimate)
            parts.push({ icon: "clock", text: `Estimate: ${parsed.estimate} min` });
        // User-defined fields
        if (parsed.userFields && Object.keys(parsed.userFields).length > 0) {
            for (const [fieldId, value] of Object.entries(parsed.userFields)) {
                const userField = this.triggerConfig.getUserField(fieldId);
                const displayName = userField?.displayName || fieldId;
                // Format value based on type
                let displayValue;
                if (Array.isArray(value)) {
                    displayValue = value.join(", ");
                }
                else {
                    displayValue = value;
                }
                parts.push({
                    icon: "box",
                    text: `${displayName}: ${displayValue}`,
                });
            }
        }
        return parts;
    }
    /**
     * Generates a simple text-only preview of the parsed data.
     */
    getPreviewText(parsed) {
        return this.getPreviewData(parsed)
            .map((part) => part.text)
            .join(" • ");
    }
    /**
     * Get status suggestions for autocomplete
     */
    getStatusSuggestions(query, limit = 10) {
        const q = query.toLowerCase();
        return this.statusConfigs
            .filter((s) => s && typeof s.value === "string" && typeof s.label === "string")
            .filter((s) => s.value.trim() !== "" && s.label.trim() !== "")
            .filter((s) => s.value.toLowerCase().includes(q) || s.label.toLowerCase().includes(q))
            .slice(0, limit)
            .map((s) => ({
            value: s.value,
            label: s.label,
            display: s.label,
        }));
    }
}
exports.NaturalLanguageParserCore = NaturalLanguageParserCore;
//# sourceMappingURL=NaturalLanguageParserCore.js.map